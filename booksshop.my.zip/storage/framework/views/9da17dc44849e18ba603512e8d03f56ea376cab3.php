
<?php $__env->startSection('title', $book->title); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/book.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="flex-md-shrink-0" >
        <div class="text-center block_title_page">
            <p class="title_page"><?php echo e($book->title); ?></p>
        </div>

        <div class="container" id="product-section">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-2">
                    </div>
                    <div class="col-md-3">
                        <img id="mainImg" class="img_page" src="<?php echo e(asset('/img/books/'.$book->id.'/'.$main_img->name)); ?>" alt="">
                        <div class="row">
                            <?php if(isset($book->images)): ?>
                                <?php $__currentLoopData = $book->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <img id="change_img" class="img_page_min" src="<?php echo e(asset('/img/books/'.$book->id.'/'.$img['name'])); ?>" alt="" style="cursor: pointer" onclick="mainImg.src='<?php echo e(asset('/img/books/'.$book->id.'/'.$img['name'])); ?>'">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="inf_page">
                            <div class="a_page"><a href="<?php echo e(url('/category/'.$book->category['id'])); ?>"><?php echo e($book->category['title']); ?></a></div>
                            <div class="a_page"><a href="<?php echo e(url('/author/'.$book->author['id'])); ?>"><?php echo e($book->author['FIO']); ?></a></div>
                            <?php if(isset($book->series)): ?>
                            <div class="a_page"><a href="<?php echo e(url('/series/'.$book->series['id'])); ?>"><?php echo e($book->series['title']); ?></a></div>
                            <?php endif; ?>
                            <div class="a_page"><a href="<?php echo e(url('/publisher/'.$book->publisher['id'])); ?>"><?php echo e($book->publisher['title']); ?></a></div>
                            <p>Имеется <?php echo e($book->available); ?> экземпляров</p>
                        </div>
                        <div class="price_page d-flex justify-content-center">
                            <p><?php echo e($book->price); ?>₽</p>
                        </div>
                        <div class="d-flex justify-content-center">
                            <button id="<?php echo e($book->id); ?>" type="submit" class="btn btn-primary btn-lg add_to_cart">В корзину</button>
                        </div>
                    </div>
                    <div class="col-md-4 description_page">
                        <p>
                            <?php echo e($book->description); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\booksshop.my\resources\views/app/book.blade.php ENDPATH**/ ?>