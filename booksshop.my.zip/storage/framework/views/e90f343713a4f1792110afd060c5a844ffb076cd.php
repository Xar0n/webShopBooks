<!doctype html>
<html lang="ru">
<head>
    <?php echo $__env->make('layouts.app.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="d-flex flex-column h-100" style="background: #E9ECEF">
<?php echo $__env->make('layouts.app.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
</body>
<!-- ФУТЕР -->
<footer class="footer mt-auto py-3 bg-dark">
    <div class="row justify-content-md-center">
        <div class="col-md-2">
            <span class="text-muted">e-mail: sale_book@mail.ru</span>
        </div>
        <div class="col-md-2">
            <span class="text-muted">Телефон: 8800553535</span>
        </div>
        <div class="col-md-2">
            <span class="text-muted">Адрес: г.Иркутск ул. Курчатова 8а, 320</span>
        </div>
        <div class="col-md-2">
            <span class="text-muted">Все права защищены© 2021</span>
        </div>
    </div>
</footer>
<?php echo $__env->make('layouts.app.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/jquery-min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-mask.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-cookie.js')); ?>"></script>
<script src="<?php echo e(asset('js/validate.js')); ?>"></script>
<script src="<?php echo e(asset('js/ajax.js')); ?>"></script>
<script src="<?php echo e(asset('js/orderInf.js')); ?>"></script>
<script src="<?php echo e(asset('js/filter.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH D:\OpenServer\domains\booksshop.my\resources\views/layouts/app.blade.php ENDPATH**/ ?>