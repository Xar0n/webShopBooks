<?php $__env->startSection('title', "Серии"); ?>
<?php $__env->startSection('content'); ?>
    <main class="flex-md-shrink-0">
        <div class="text-center block_title_page">
            <p class="title_page">Серии</p>
        </div>
        <div class="col-md-12 col-lg-12 col-xl-12">
            <?php if(isset($series)): ?>
                <?php $j = 0;?>
                <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($j == 0): ?>

                        <div class="row justify-content-md-center block_series">
                            <div class="col-md-1 col-lg-1">
                                <a href="<?php echo e(url('/series/'.$serie->id)); ?>"><img class="img_series" src="<?php echo e(asset('/img/series/'.$serie->img)); ?>" alt=""></a>
                            </div>
                            <div class="col-md-2 col-lg-2 blockTitle_series">
                                <a href="<?php echo e(url('/series/'.$serie->id)); ?>" class="text-decoration-none">
                                    <p class="title_series"><?php echo e($serie->author['FIO']); ?> <br> <?php echo e($serie->title); ?></p>
                                </a>
                            </div>
                            <div class="col-md-2 col-lg-2">
                            </div>

                        <?php endif; ?>

                            <?php if($j == 1): ?>
                                <div class="col-md-1 col-lg-1">
                                    <a href="<?php echo e(url('/series/'.$serie->id)); ?>"><img class="img_series" src="<?php echo e(asset('/img/series/'.$serie->img)); ?>" alt=""></a>
                                </div>
                                <div class="col-md-2 col-lg-2 blockTitle_series">
                                    <a href="<?php echo e(url('/series/'.$serie->id)); ?>" class="text-decoration-none">
                                        <p class="title_series"><?php echo e($serie->author['FIO']); ?> <br> <?php echo e($serie->title); ?></p>
                                    </a>
                                </div>
                        </div>
                        <?php $j = 0;?>
                    <?php else: ?>
                        <?php  $j++; ?>
                            <?php endif; ?>


                            <?php if($last_id == $serie->id): ?>
                                <?php  $j = 0 ?>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-1">
                        </div>
                        <div class="col-md-10">
                            <nav aria-label="...">
                                <ul class="pagination">
                                    <?php echo e($series->links('pagination::bootstrap-4')); ?>

                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\booksshop.my\resources\views/app/series.blade.php ENDPATH**/ ?>