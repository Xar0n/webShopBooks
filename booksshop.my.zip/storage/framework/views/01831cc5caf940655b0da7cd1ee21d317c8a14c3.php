<?php $__env->startSection('title', $publisher->title); ?>
<?php $__env->startSection('content'); ?>
    <main class="flex-md-shrink-0" >
        <div class="col-md-12 block">
            <p class="block-title">Издательство: <?php echo e($publisher->title); ?></p>
            <?php if(isset($books)): ?>
                <?php $j = 0;?>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($j == 0): ?>
                        <div class="row justify-content-md-center">
                            <?php endif; ?>
                            <div class="col-md-2">
                                <div class="product2">
                                    <div class="col" style="background:#DEE2E6">
                                        <p class="product-title2"> <a href="<?php echo e(url('/book/'.$book->id)); ?>"><?php echo e($book->title); ?></a></p>
                                    </div>
                                    <div class="col">
                                        <div class="product-img2"> <a href="<?php echo e(url('/book/'.$book->id)); ?>"><img src="<?php echo e(asset('/img/books/'.$book->id.'/'.$book->img['name'])); ?>" alt="" class="img2"></a></div>
                                    </div>
                                    <div class="col">
                                        <p class="product-author"><?php echo e($book->author['FIO']); ?></p>
                                    </div>
                                    <div class="col">
                                        <p class="product-price2"><?php echo e($book->price); ?>₽</p>
                                    </div>
                                    <div class="col">
                                        <button id="<?php echo e($book->id); ?>" type="button" class="btn btn-primary button-buy add_to_cart">В корзину</button>
                                    </div>
                                </div>
                            </div>
                            <?php  $j++; ?>
                            <?php if($j == 5 || $last_id == $book->id): ?>
                                <?php  $j = 0 ?>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-md-2">
                    <p>Нет книг данного издательства</p>
                </div>
            <?php endif; ?>
        </div>
        <!-- ПАГИНАЦИЯ -->
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-1">
                </div>
                <div class="col-md-10">
                    <nav aria-label="...">
                        <ul class="pagination">
                            <?php echo e($books->links('pagination::bootstrap-4')); ?>

                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\booksshop.my\resources\views/app/publisher.blade.php ENDPATH**/ ?>